# Encrypted Chat App (Android - Java)

This is an encrypted chat application for Android, developed in Java, that provides secure communication between users by encrypting and decrypting messages using the AES (Advanced Encryption Standard) algorithm. The app stores the encrypted messages in Firebase Realtime Database, ensuring the confidentiality of the communication.

## Features

- Secure end-to-end encrypted messaging using AES encryption.
- User-friendly interface for a seamless chat experience.
- Real-time message updates using Firebase Realtime Database.
- Account creation and authentication for secure access.
- Secure storage of encrypted messages on the server.

## Prerequisites

To run the application and make modifications, you need to have the following prerequisites installed:

- Android Studio (v4.1 or higher)
- Java Development Kit (JDK 8 or higher)
- Firebase account with a project set up
- Google Play services and Firebase dependencies added to the project


2. Open Android Studio and import the project:

   - Click on "Open an existing Android Studio project."
   - Navigate to the cloned repository's location and select the project directory.

3. Configure Firebase:

   - Create a new Firebase project at [https://console.firebase.google.com](https://console.firebase.google.com).
   - Add an Android app to your Firebase project, providing the necessary details.
   - Download the `google-services.json` file from the Firebase console.
   - Place the `google-services.json` file inside the `app` directory of your Android Studio project.

4. Build and run the project on an emulator or physical device.


